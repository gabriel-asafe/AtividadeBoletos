package com.exemplo.boleto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public abstract class BoletoBuilderBase implements BoletoBuilder {
    protected Boleto boleto;
    
    public BoletoBuilderBase() {
        boleto = new Boleto();
        boleto.setCodigoBanco(getCodigoBanco());
    }
    
    protected abstract String getCodigoBanco();
    
    @Override
    public BoletoBuilder comBeneficiario(String nome, String cpfCnpj, String endereco) {
        boleto.setBeneficiarioNome(nome);
        boleto.setBeneficiarioCpfCnpj(cpfCnpj);
        boleto.setBeneficiarioEndereco(endereco);
        return this;
    }
    
    @Override
    public BoletoBuilder comSacado(String nome, String cpfCnpj, String endereco) {
        boleto.setSacadoNome(nome);
        boleto.setSacadoCpfCnpj(cpfCnpj);
        boleto.setSacadoEndereco(endereco);
        return this;
    }
    
    @Override
    public BoletoBuilder comDocumento(String numero, LocalDate vencimento, BigDecimal valor) {
        boleto.setNumeroDocumento(numero);
        boleto.setDataVencimento(vencimento);
        boleto.setValor(valor);
        return this;
    }
    
    @Override
    public BoletoBuilder comDadosBancarios(String agencia, String contaCorrente, String carteira) {
        boleto.setAgencia(agencia);
        boleto.setContaCorrente(contaCorrente);
        boleto.setCarteira(carteira);
        return this;
    }
    
    protected int calcularFatorVencimento(LocalDate dataVencimento) {
        LocalDate dataBase = LocalDate.of(1997, 10, 7);
        return (int) ChronoUnit.DAYS.between(dataBase, dataVencimento);
    }
    
    protected String calcularDVModulo11(String numero) {
        int soma = 0;
        int peso = 2;
        
        for (int i = numero.length() - 1; i >= 0; i--) {
            int digito = Character.getNumericValue(numero.charAt(i));
            soma += digito * peso;
            peso = peso == 9 ? 2 : peso + 1;
        }
        
        int resto = soma % 11;
        int dv = 11 - resto;
        
        if (dv == 0 || dv == 1 || dv > 9) {
            return "1";
        }
        
        return String.valueOf(dv);
    }
    
    protected String calcularDVModulo10(String numero) {
        int soma = 0;
        boolean multiplicarPor2 = true;
        
        for (int i = numero.length() - 1; i >= 0; i--) {
            int digito = Character.getNumericValue(numero.charAt(i));
            if (multiplicarPor2) {
                digito *= 2;
                if (digito > 9) {
                    digito -= 9;
                }
            }
            soma += digito;
            multiplicarPor2 = !multiplicarPor2;
        }
        
        int resto = soma % 10;
        return String.valueOf((10 - resto) % 10);
    }
    
    protected String formatarValor(BigDecimal valor) {
        return String.format("%010d", valor.multiply(BigDecimal.valueOf(100)).longValue());
    }
    
    @Override
    public Boleto build() {
        if (!validarDados()) {
            throw new IllegalStateException("Dados do boleto incompletos ou inválidos");
        }
        calcularCampos();
        return boleto;
    }
    
    protected boolean validarDados() {
        return boleto.getBeneficiarioNome() != null &&
               boleto.getBeneficiarioCpfCnpj() != null &&
               boleto.getSacadoNome() != null &&
               boleto.getSacadoCpfCnpj() != null &&
               boleto.getNumeroDocumento() != null &&
               boleto.getDataVencimento() != null &&
               boleto.getValor() != null &&
               boleto.getAgencia() != null &&
               boleto.getContaCorrente() != null &&
               boleto.getCarteira() != null;
    }
}

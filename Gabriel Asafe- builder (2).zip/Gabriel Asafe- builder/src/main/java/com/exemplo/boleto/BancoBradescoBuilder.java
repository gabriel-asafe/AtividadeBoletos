package com.exemplo.boleto;

public class BancoBradescoBuilder extends BoletoBuilderBase {
    @Override
    protected String getCodigoBanco() {
        return "237";
    }
    
    @Override
    public void calcularCampos() {
      
        StringBuilder codigoBarras = new StringBuilder();
        
        codigoBarras.append(getCodigoBanco());
        
        codigoBarras.append("9");
        
        codigoBarras.append("0");
        
        codigoBarras.append(String.format("%04d", calcularFatorVencimento(boleto.getDataVencimento())));
        
        codigoBarras.append(formatarValor(boleto.getValor()));
        
    
        codigoBarras.append(String.format("%04d", 
            Integer.parseInt(boleto.getAgencia().replaceAll("\\D", ""))));
        
        codigoBarras.append(String.format("%02d", 
            Integer.parseInt(boleto.getCarteira().replaceAll("\\D", ""))));
        
        String nossoNumero = String.format("%011d", 
            Long.parseLong(boleto.getNumeroDocumento().replaceAll("\\D", "").substring(0, 
            Math.min(11, boleto.getNumeroDocumento().length()))));
        codigoBarras.append(nossoNumero);
        
        codigoBarras.append(String.format("%07d", 
            Long.parseLong(boleto.getContaCorrente().replaceAll("\\D", ""))));
        
        codigoBarras.append("0");
        
        String codigoSemDv = codigoBarras.toString();
        String dv = calcularDVModulo11(codigoSemDv.substring(0, 4) + codigoSemDv.substring(5));
        
        codigoBarras.setCharAt(4, dv.charAt(0));
        
        boleto.setCodigoBarras(codigoBarras.toString());
        
        StringBuilder linhaDigitavel = new StringBuilder();
        
        String campo1 = codigoBarras.substring(0, 4) + codigoBarras.substring(19, 24);
        linhaDigitavel.append(campo1).append(calcularDVModulo10(campo1)).append(".");
        
        String campo2 = codigoBarras.substring(24, 34);
        linhaDigitavel.append(campo2).append(calcularDVModulo10(campo2)).append(".");
        
        String campo3 = codigoBarras.substring(34, 44);
        linhaDigitavel.append(campo3).append(calcularDVModulo10(campo3)).append(".");
        
        linhaDigitavel.append(dv).append(".");
        
        linhaDigitavel.append(codigoBarras.substring(5, 9))
                     .append(codigoBarras.substring(9, 19));
        
        boleto.setLinhaDigitavel(linhaDigitavel.toString());
    }
}

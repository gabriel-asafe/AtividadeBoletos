package com.exemplo.boleto;

public class BancoItauBuilder extends BoletoBuilderBase {
    @Override
    protected String getCodigoBanco() {
        return "341";
    }
    
    @Override
    public void calcularCampos() {
        StringBuilder codigoBarras = new StringBuilder();
        
        codigoBarras.append(getCodigoBanco());
        
        codigoBarras.append("9");
        
        codigoBarras.append("0");
        
        codigoBarras.append(String.format("%04d", calcularFatorVencimento(boleto.getDataVencimento())));
        
        codigoBarras.append(formatarValor(boleto.getValor()));
      
        codigoBarras.append(String.format("%03d", 
            Integer.parseInt(boleto.getCarteira().replaceAll("\\D", ""))));
        
        codigoBarras.append(String.format("%08d", 
            Long.parseLong(boleto.getNumeroDocumento().replaceAll("\\D", "").substring(0, 
            Math.min(8, boleto.getNumeroDocumento().length())))));
        
        String dadosParaDac = String.format("%03d%08d%04d%05d",
            Integer.parseInt(boleto.getCarteira().replaceAll("\\D", "")),
            Long.parseLong(boleto.getNumeroDocumento().replaceAll("\\D", "").substring(0, 
            Math.min(8, boleto.getNumeroDocumento().length()))),
            Integer.parseInt(boleto.getAgencia().replaceAll("\\D", "")),
            Integer.parseInt(boleto.getContaCorrente().replaceAll("\\D", "")));
        codigoBarras.append(calcularDVModulo10(dadosParaDac));

        codigoBarras.append(String.format("%04d", 
            Integer.parseInt(boleto.getAgencia().replaceAll("\\D", ""))));
        
        
        codigoBarras.append(String.format("%05d", 
            Integer.parseInt(boleto.getContaCorrente().replaceAll("\\D", ""))));
        
       
        String dacAgConta = boleto.getAgencia() + boleto.getContaCorrente();
        codigoBarras.append(calcularDVModulo10(dacAgConta));
        
        codigoBarras.append("000");
        
        String codigoSemDv = codigoBarras.toString();
        String dv = calcularDVModulo11(codigoSemDv.substring(0, 4) + codigoSemDv.substring(5));
        
        codigoBarras.setCharAt(4, dv.charAt(0));
        
        boleto.setCodigoBarras(codigoBarras.toString());
        
        StringBuilder linhaDigitavel = new StringBuilder();
        
        String campo1 = codigoBarras.substring(0, 4) + codigoBarras.substring(19, 24);
        linhaDigitavel.append(campo1).append(calcularDVModulo10(campo1)).append(".");
        
        String campo2 = codigoBarras.substring(24, 34);
        linhaDigitavel.append(campo2).append(calcularDVModulo10(campo2)).append(".");
        
        String campo3 = codigoBarras.substring(34, 44);
        linhaDigitavel.append(campo3).append(calcularDVModulo10(campo3)).append(".");
        
        linhaDigitavel.append(dv).append(".");
        
        linhaDigitavel.append(codigoBarras.substring(5, 9))
                     .append(codigoBarras.substring(9, 19));
        
        boleto.setLinhaDigitavel(linhaDigitavel.toString());
    }
}

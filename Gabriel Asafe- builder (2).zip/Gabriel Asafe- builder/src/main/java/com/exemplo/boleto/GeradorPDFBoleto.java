package com.exemplo.boleto;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.oned.Code128Writer;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.borders.SolidBorder;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.UnitValue;
import com.itextpdf.layout.properties.VerticalAlignment;

import java.io.ByteArrayOutputStream;
import java.nio.file.Path;
import java.text.NumberFormat;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class GeradorPDFBoleto {
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final NumberFormat CURRENCY_FORMATTER = NumberFormat.getCurrencyInstance(Locale.of("pt", "BR"));
    
    public void gerarPDF(Boleto boleto, Path outputPath) {
        try {
            
            Path boletosDir = Path.of("boletos");
            if (!java.nio.file.Files.exists(boletosDir)) {
                java.nio.file.Files.createDirectory(boletosDir);
            }
            
            Path finalPath = boletosDir.resolve(outputPath.getFileName());
            PdfWriter writer = new PdfWriter(finalPath.toString());
            PdfDocument pdf = new PdfDocument(writer);
            Document document = new Document(pdf);
            
            DeviceRgb corBanco;
            String nomeBanco;
            
            switch (boleto.getCodigoBanco()) {
                case "001": 
                    corBanco = new DeviceRgb(255, 242, 0); 
                    nomeBanco = "BANCO DO BRASIL S.A.";
                    break;
                case "341": 
                    corBanco = new DeviceRgb(236, 122, 27); 
                    nomeBanco = "BANCO ITAÚ S.A.";
                    break;
                case "237": 
                    corBanco = new DeviceRgb(205, 0, 0);
                    nomeBanco = "BANCO BRADESCO S.A.";
                    break;
                default:
                    corBanco = new DeviceRgb(100, 100, 100);
                    nomeBanco = "BANCO";
            }
            
          
            Table header = new Table(2);
            header.setWidth(UnitValue.createPercentValue(100));
            
            
            Cell bankCell = new Cell();
            bankCell.add(new Paragraph(nomeBanco)
                .setFontSize(16)
                .setBold()
                .setFontColor(corBanco));
            bankCell.add(new Paragraph(boleto.getCodigoBanco())
                .setFontSize(20)
                .setBold());
            bankCell.setBorder(new SolidBorder(corBanco, 2));
            bankCell.setBackgroundColor(ColorConstants.WHITE);
            header.addCell(bankCell);
            
            Cell barcodeCell = new Cell();
            barcodeCell.add(new Paragraph("Linha Digitável")
                .setFontSize(8)
                .setFontColor(ColorConstants.GRAY));
            barcodeCell.add(new Paragraph(boleto.getLinhaDigitavel())
                .setFontSize(12)
                .setBold());
            barcodeCell.setBorder(new SolidBorder(corBanco, 2));
            header.addCell(barcodeCell);
            
            document.add(header);
            
            Table paymentInfo = new Table(2);
            paymentInfo.setWidth(UnitValue.createPercentValue(100));
            paymentInfo.setMarginTop(20);
            
            addTableRow(paymentInfo, "Beneficiário", boleto.getBeneficiarioNome(), corBanco);
            addTableRow(paymentInfo, "CPF/CNPJ", boleto.getBeneficiarioCpfCnpj(), corBanco);
            addTableRow(paymentInfo, "Pagador", boleto.getSacadoNome(), corBanco);
            addTableRow(paymentInfo, "Vencimento", boleto.getDataVencimento().format(DATE_FORMATTER), corBanco);
            addTableRow(paymentInfo, "Valor", CURRENCY_FORMATTER.format(boleto.getValor()), corBanco);
            
            document.add(paymentInfo);
            
            document.add(new Paragraph("\nCódigo de Barras")
                .setBold()
                .setFontColor(corBanco));
            
            Code128Writer barcodeWriter = new Code128Writer();
            BitMatrix bitMatrix = barcodeWriter.encode(
                boleto.getCodigoBarras(),
                BarcodeFormat.CODE_128,
                400,
                100
            );
            
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            MatrixToImageWriter.writeToStream(bitMatrix, "PNG", baos);
            
            Image barcodeImage = new Image(ImageDataFactory.create(baos.toByteArray()));
            barcodeImage.setWidth(UnitValue.createPercentValue(100));
            barcodeImage.setMarginTop(10);
            barcodeImage.setMarginBottom(10);
            document.add(barcodeImage);
            
            Table instructions = new Table(1);
            instructions.setWidth(UnitValue.createPercentValue(100));
            instructions.setMarginTop(20);
            
            Cell instructionsCell = new Cell();
            instructionsCell.add(new Paragraph("Instruções")
                .setBold()
                .setFontColor(corBanco));
            instructionsCell.add(new Paragraph("1. Avalie esse boleto")
                .setFontSize(8));
            instructionsCell.add(new Paragraph("2. Dê nota a Asafe")
                .setFontSize(8));
            instructionsCell.setBorder(new SolidBorder(corBanco, 0.5f));
            
            instructions.addCell(instructionsCell);
            document.add(instructions);
            
   
            document.add(new Paragraph("\nValidação de Fabinho")
                .setFontSize(8)
                .setTextAlignment(TextAlignment.RIGHT)
                .setFontColor(ColorConstants.GRAY));
            
            document.close();
            
        } catch (Exception e) {
            throw new RuntimeException("Erro ao gerar PDF do boleto", e);
        }
    }
    
    private void addTableRow(Table table, String label, String value, DeviceRgb color) {
        Cell labelCell = new Cell();
        labelCell.add(new Paragraph(label)
            .setFontSize(8)
            .setFontColor(ColorConstants.GRAY));
        labelCell.setBorder(new SolidBorder(color, 0.5f));
        labelCell.setVerticalAlignment(VerticalAlignment.MIDDLE);
        
        Cell valueCell = new Cell();
        valueCell.add(new Paragraph(value)
            .setFontSize(10)
            .setBold());
        valueCell.setBorder(new SolidBorder(color, 0.5f));
        valueCell.setVerticalAlignment(VerticalAlignment.MIDDLE);
        
        table.addCell(labelCell);
        table.addCell(valueCell);
    }
}

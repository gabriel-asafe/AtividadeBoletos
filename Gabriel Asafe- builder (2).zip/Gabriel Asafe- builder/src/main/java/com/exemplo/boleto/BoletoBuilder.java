package com.exemplo.boleto;

import java.math.BigDecimal;
import java.time.LocalDate;

public interface BoletoBuilder {
    BoletoBuilder comBeneficiario(String nome, String cpfCnpj, String endereco);
    BoletoBuilder comSacado(String nome, String cpfCnpj, String endereco);
    BoletoBuilder comDocumento(String numero, LocalDate vencimento, BigDecimal valor);
    BoletoBuilder comDadosBancarios(String agencia, String contaCorrente, String carteira);
    void calcularCampos();
    Boleto build();
}

package com.exemplo.boleto;

import java.math.BigDecimal;
import java.nio.file.Paths;
import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        BoletoDiretor diretor = new BoletoDiretor();
           
        BoletoBuilder bbBuilder = new BancoBrasilBuilder();
        diretor.setBuilder(bbBuilder);
        
        Boleto boletoBB = diretor.construirBoleto(
            "Empresa ABC Ltda", "12.345.678/0001-90", "Rua A, 123 - São Paulo/SP",
            "Fabinho", "987.654.321-00", "Rua B, 001 - Eunápolis/BA",
            "12345", LocalDate.now().plusDays(30), new BigDecimal("550.00"),
            "1234", "56789", "17"
        );
        
        GeradorPDFBoleto geradorPDF = new GeradorPDFBoleto();
        geradorPDF.gerarPDF(boletoBB, Paths.get("boleto_bb.pdf"));
        
        BoletoBuilder itauBuilder = new BancoItauBuilder();
        diretor.setBuilder(itauBuilder);
        
        Boleto boletoItau = diretor.construirBoleto(
            "Fabinho", "12.345.678/0001-90", "Rua B, 001 - Eunápolis/BA",
            "Asafe", "987.654.321-00", "Rua Atlântico, 120 -Ivan Moura/BA",
            "54321", LocalDate.now().plusDays(30), new BigDecimal("750.00"),
            "4321", "98765", "109"
        );
        
       
        geradorPDF.gerarPDF(boletoItau, Paths.get("boleto_itau.pdf"));
        
       
        BoletoBuilder bradescoBuilder = new BancoBradescoBuilder();
        diretor.setBuilder(bradescoBuilder);
        
        Boleto boletoBradesco = diretor.construirBoleto(
            "Empresa ABC Ltda", "12.345.678/0001-90", "Rua A, 123 - São Paulo/SP",
            "Cliente exemplo 3", "987.654.321-00", "Rua B, 456 - Rio de Janeiro/RJ",
            "98765", LocalDate.now().plusDays(30), new BigDecimal("1250.00"),
            "5678", "12345", "09"
        );
        
  
        geradorPDF.gerarPDF(boletoBradesco, Paths.get("boleto_bradesco.pdf"));
        
        System.out.println("Boletos gerados com sucesso!");
        
    
        System.out.println("\nBoleto Banco do Brasil:");
        System.out.println("Linha Digitável: " + boletoBB.getLinhaDigitavel());
        System.out.println("Código de Barras: " + boletoBB.getCodigoBarras());
        
        System.out.println("\nBoleto Itaú:");
        System.out.println("Linha Digitável: " + boletoItau.getLinhaDigitavel());
        System.out.println("Código de Barras: " + boletoItau.getCodigoBarras());
        
        System.out.println("\nBoleto Bradesco:");
        System.out.println("Linha Digitável: " + boletoBradesco.getLinhaDigitavel());
        System.out.println("Código de Barras: " + boletoBradesco.getCodigoBarras());
    }
}

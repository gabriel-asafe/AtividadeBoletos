package com.exemplo.boleto;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Boleto {

    private String beneficiarioNome;
    private String beneficiarioCpfCnpj;
    private String beneficiarioEndereco;

    private String sacadoNome;
    private String sacadoCpfCnpj;
    private String sacadoEndereco;

    private String numeroDocumento;
    private LocalDate dataVencimento;
    private BigDecimal valor;

    private String codigoBanco;
    private String agencia;
    private String contaCorrente;
    private String carteira;

    private String linhaDigitavel;
    private String codigoBarras;


    public String getBeneficiarioNome() { 
        return beneficiarioNome; }
    public void setBeneficiarioNome(String beneficiarioNome) { 
        this.beneficiarioNome = beneficiarioNome; }

    public String getBeneficiarioCpfCnpj() { 
        return beneficiarioCpfCnpj; }
    public void setBeneficiarioCpfCnpj(String beneficiarioCpfCnpj) { 
        this.beneficiarioCpfCnpj = beneficiarioCpfCnpj; }

    public String getBeneficiarioEndereco() {
         return beneficiarioEndereco; }
    public void setBeneficiarioEndereco(String beneficiarioEndereco) {
         this.beneficiarioEndereco = beneficiarioEndereco; }

    public String getSacadoNome() { 
        return sacadoNome; }
    public void setSacadoNome(String sacadoNome) {
         this.sacadoNome = sacadoNome; }

    public String getSacadoCpfCnpj() { 
        return sacadoCpfCnpj; }
    public void setSacadoCpfCnpj(String sacadoCpfCnpj) { 
        this.sacadoCpfCnpj = sacadoCpfCnpj; }

    public String getSacadoEndereco() { 
        return sacadoEndereco; }
    public void setSacadoEndereco(String sacadoEndereco) { 
        this.sacadoEndereco = sacadoEndereco; }

    public String getNumeroDocumento() { 
        return numeroDocumento; }
    public void setNumeroDocumento(String numeroDocumento) {
         this.numeroDocumento = numeroDocumento; }

    public LocalDate getDataVencimento() {
         return dataVencimento; }
    public void setDataVencimento(LocalDate dataVencimento) { 
        this.dataVencimento = dataVencimento; }

    public BigDecimal getValor() {
         return valor; }
    public void setValor(BigDecimal valor) { 
        this.valor = valor; }

    public String getCodigoBanco() {
         return codigoBanco; }
    public void setCodigoBanco(String codigoBanco) { 
        this.codigoBanco = codigoBanco; }

    public String getAgencia() { 
        return agencia; }
    public void setAgencia(String agencia) { 
        this.agencia = agencia; }

    public String getContaCorrente() {
         return contaCorrente; }
    public void setContaCorrente(String contaCorrente) {
         this.contaCorrente = contaCorrente; }

    public String getCarteira() { return carteira; }
    public void setCarteira(String carteira) { this.carteira = carteira; }

    public String getLinhaDigitavel() {
         return linhaDigitavel; }
    public void setLinhaDigitavel(String linhaDigitavel) { 
        this.linhaDigitavel = linhaDigitavel; }

    public String getCodigoBarras() {
         return codigoBarras; }
    public void setCodigoBarras(String codigoBarras) { 
        this.codigoBarras = codigoBarras; }
}

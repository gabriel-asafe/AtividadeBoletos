package com.exemplo.boleto;

import java.math.BigDecimal;
import java.time.LocalDate;

public class BoletoDiretor {
    private BoletoBuilder builder;
    
    public void setBuilder(BoletoBuilder builder) {
        this.builder = builder;
    }
    
    public Boleto construirBoleto(String beneficiarioNome, String beneficiarioCpfCnpj, String beneficiarioEndereco,
                                 String sacadoNome, String sacadoCpfCnpj, String sacadoEndereco,
                                 String numeroDocumento, LocalDate vencimento, BigDecimal valor,
                                 String agencia, String contaCorrente, String carteira) {
        return builder
            .comBeneficiario(beneficiarioNome, beneficiarioCpfCnpj, beneficiarioEndereco)
            .comSacado(sacadoNome, sacadoCpfCnpj, sacadoEndereco)
            .comDocumento(numeroDocumento, vencimento, valor)
            .comDadosBancarios(agencia, contaCorrente, carteira)
            .build();
    }
}

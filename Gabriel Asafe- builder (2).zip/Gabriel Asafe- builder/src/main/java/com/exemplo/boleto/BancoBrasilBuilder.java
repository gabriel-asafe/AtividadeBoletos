package com.exemplo.boleto;

public class BancoBrasilBuilder extends BoletoBuilderBase {
    @Override
    protected String getCodigoBanco() {
        return "001";
    }
    
    @Override
    public void calcularCampos() {
        StringBuilder codigoBarras = new StringBuilder();
        
        codigoBarras.append(getCodigoBanco());
        
        codigoBarras.append("9");
        
        codigoBarras.append("0");
        
        codigoBarras.append(String.format("%04d", calcularFatorVencimento(boleto.getDataVencimento())));
        
        codigoBarras.append(formatarValor(boleto.getValor()));
        
        String convenio = boleto.getContaCorrente().substring(0, Math.min(6, boleto.getContaCorrente().length()));
        codigoBarras.append(String.format("%-6s", convenio).replace(' ', '0'));
   
        String numeroDocumento = boleto.getNumeroDocumento().replaceAll("\\D", "");
        codigoBarras.append(String.format("%07d", 
            Long.parseLong(numeroDocumento.substring(0, Math.min(7, numeroDocumento.length())))));
        
  
        codigoBarras.append(boleto.getCarteira());
        
      
        String agencia = boleto.getAgencia().replaceAll("\\D", "");
        codigoBarras.append(String.format("%04d", 
            Integer.parseInt(agencia.substring(0, Math.min(4, agencia.length())))));
        
        String contaComDv = boleto.getContaCorrente().replaceAll("\\D", "");
        codigoBarras.append(String.format("%07d", 
            Long.parseLong(contaComDv.substring(0, Math.min(7, contaComDv.length())))));
   
        String codigoSemDv = codigoBarras.toString();
        String dv = calcularDVModulo11(codigoSemDv.substring(0, 4) + codigoSemDv.substring(5));
        
   
        codigoBarras.setCharAt(4, dv.charAt(0));
        
        boleto.setCodigoBarras(codigoBarras.toString());
        
        StringBuilder linhaDigitavel = new StringBuilder();
        

        String campo1 = codigoBarras.substring(0, 4) + codigoBarras.substring(19, 24);
        linhaDigitavel.append(campo1).append(calcularDVModulo10(campo1)).append(".");
        
       
        String campo2 = codigoBarras.substring(24, 34);
        linhaDigitavel.append(campo2).append(calcularDVModulo10(campo2)).append(".");
   
        String campo3 = codigoBarras.substring(34, 44);
        linhaDigitavel.append(campo3).append(calcularDVModulo10(campo3)).append(".");
        
        linhaDigitavel.append(dv).append(".");
        
     
        linhaDigitavel.append(codigoBarras.substring(5, 9))
                     .append(codigoBarras.substring(9, 19));
        
        boleto.setLinhaDigitavel(linhaDigitavel.toString());
    }
}
